// 城厢古镇景点介绍网站JavaScript文件

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 初始化 GSAP ScrollTrigger
    gsap.registerPlugin(ScrollTrigger);
    
    // Hero 区动画
    gsap.to('#hero-title', {
        opacity: 1,
        y: 0,
        duration: 1,
        delay: 0.5
    });
    
    gsap.to('#hero-subtitle', {
        opacity: 1,
        y: 0,
        duration: 1,
        delay: 0.8
    });
    
    gsap.to('#hero-button', {
        opacity: 1,
        y: 0,
        duration: 1,
        delay: 1.1
    });
    
    // 导航栏滚动效果
    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('py-2');
            navbar.classList.remove('py-3');
        } else {
            navbar.classList.add('py-3');
            navbar.classList.remove('py-2');
        }
    });
    
    // 移动端菜单
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    
    mobileMenuButton.addEventListener('click', function() {
        mobileMenu.classList.toggle('hidden');
    });
    
    // 导航链接点击事件
    const navLinks = document.querySelectorAll('.nav-link');
    const mobileNavLinks = document.querySelectorAll('#mobile-menu a');
    
    function setActiveLink() {
        const scrollPosition = window.scrollY;
        
        document.querySelectorAll('section').forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');
            
            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${sectionId}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }
    
    window.addEventListener('scroll', setActiveLink);
    setActiveLink();
    
    // 移动端导航链接点击关闭菜单
    mobileNavLinks.forEach(link => {
        link.addEventListener('click', function() {
            mobileMenu.classList.add('hidden');
        });
    });
    
    // 景点介绍动画
    gsap.to('#attractions-title', {
        scrollTrigger: {
            trigger: '#attractions',
            start: 'top 80%'
        },
        opacity: 1,
        y: 0,
        duration: 0.8
    });
    
    gsap.to('#attractions-line', {
        scrollTrigger: {
            trigger: '#attractions',
            start: 'top 80%'
        },
        opacity: 1,
        width: '6rem',
        duration: 0.8,
        delay: 0.2
    });
    
    gsap.to('#attractions-subtitle', {
        scrollTrigger: {
            trigger: '#attractions',
            start: 'top 80%'
        },
        opacity: 1,
        y: 0,
        duration: 0.8,
        delay: 0.4
    });
    
    // 景点卡片动画
    const attractionCards = document.querySelectorAll('#attractions-grid > div');
    attractionCards.forEach(card => {
        const delay = card.getAttribute('data-delay') || 0;
        gsap.to(card, {
            scrollTrigger: {
                trigger: card,
                start: 'top 85%'
            },
            opacity: 1,
            y: 0,
            duration: 0.8,
            delay: delay
        });
    });
    
    // 历史沿革动画
    gsap.to('#history-title', {
        scrollTrigger: {
            trigger: '#history',
            start: 'top 80%'
        },
        opacity: 1,
        y: 0,
        duration: 0.8
    });
    
    gsap.to('#history-line', {
        scrollTrigger: {
            trigger: '#history',
            start: 'top 80%'
        },
        opacity: 1,
        width: '6rem',
        duration: 0.8,
        delay: 0.2
    });
    
    gsap.to('#history-subtitle', {
        scrollTrigger: {
            trigger: '#history',
            start: 'top 80%'
        },
        opacity: 1,
        y: 0,
        duration: 0.8,
        delay: 0.4
    });
    
    // 时间轴项目动画
    const timelineItems = document.querySelectorAll('.timeline-item');
    timelineItems.forEach(item => {
        const delay = item.getAttribute('data-delay') || 0;
        gsap.to(item, {
            scrollTrigger: {
                trigger: item,
                start: 'top 85%'
            },
            opacity: 1,
            x: 0,
            duration: 0.8,
            delay: delay
        });
    });
    
    // 交通信息动画
    gsap.to('#transportation-title', {
        scrollTrigger: {
            trigger: '#transportation',
            start: 'top 80%'
        },
        opacity: 1,
        y: 0,
        duration: 0.8
    });
    
    gsap.to('#transportation-line', {
        scrollTrigger: {
            trigger: '#transportation',
            start: 'top 80%'
        },
        opacity: 1,
        width: '6rem',
        duration: 0.8,
        delay: 0.2
    });
    
    gsap.to('#transportation-subtitle', {
        scrollTrigger: {
            trigger: '#transportation',
            start: 'top 80%'
        },
        opacity: 1,
        y: 0,
        duration: 0.8,
        delay: 0.4
    });
    
    gsap.to('#driving-card', {
        scrollTrigger: {
            trigger: '#driving-card',
            start: 'top 85%'
        },
        opacity: 1,
        y: 0,
        duration: 0.8,
        delay: 0.6
    });
    
    gsap.to('#bus-card', {
        scrollTrigger: {
            trigger: '#bus-card',
            start: 'top 85%'
        },
        opacity: 1,
        y: 0,
        duration: 0.8,
        delay: 0.8
    });
    
    gsap.to('#map-container', {
        scrollTrigger: {
            trigger: '#map-container',
            start: 'top 85%'
        },
        opacity: 1,
        y: 0,
        duration: 0.8,
        delay: 1
    });
    
    // 特色体验动画
    gsap.to('#experience-title', {
        scrollTrigger: {
            trigger: '#experience',
            start: 'top 80%'
        },
        opacity: 1,
        y: 0,
        duration: 0.8
    });
    
    gsap.to('#experience-line', {
        scrollTrigger: {
            trigger: '#experience',
            start: 'top 80%'
        },
        opacity: 1,
        width: '6rem',
        duration: 0.8,
        delay: 0.2
    });
    
    gsap.to('#experience-subtitle', {
        scrollTrigger: {
            trigger: '#experience',
            start: 'top 80%'
        },
        opacity: 1,
        y: 0,
        duration: 0.8,
        delay: 0.4
    });
    
    // 特色体验卡片动画
    const experienceCards = document.querySelectorAll('#experience .grid > div');
    experienceCards.forEach(card => {
        const delay = card.getAttribute('data-delay') || 0;
        gsap.to(card, {
            scrollTrigger: {
                trigger: card,
                start: 'top 85%'
            },
            opacity: 1,
            y: 0,
            duration: 0.8,
            delay: delay
        });
    });
    
    gsap.to('#food-section', {
        scrollTrigger: {
            trigger: '#food-section',
            start: 'top 85%'
        },
        opacity: 1,
        y: 0,
        duration: 0.8,
        delay: 0.8
    });
    
    // 景点详情模态框
    const modal = document.getElementById('attraction-modal');
    const modalOverlay = document.getElementById('modal-overlay');
    const closeModal = document.getElementById('close-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalImage = document.getElementById('modal-image');
    const modalDescription = document.getElementById('modal-description');
    const viewDetailsButtons = document.querySelectorAll('.view-details');
    
    // 景点数据
    const attractionsData = [
        {
            id: 1,
            title: '绣川书院',
            image: 'https://p26-doubao-search-sign.byteimg.com/tos-cn-i-6w9my0ksvp/f87b026e7d9449d7bf25717a9f9f19c0~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1785769687&x-signature=BSMzPghvh6fhh3xa%2FHcViiIo6s8%3D',
            description: `绣川书院始建于北宋，是成都地区规模最大的书院之一，也是川西保存最为完好的古代县级官办书院。历史上曾为巴蜀地区培养过很多人才，朱熹曾在此讲学。

这里走出了北宋理学名家谢湜、当代诗人流沙河等名人。在八百年间里，这片圣地先后培育了北宋理学家谢湜、清代文史学家张晋生、辛亥革命功臣彭家珍、当代哲学家贺麟、当代植物学家何铸、当代著名学者何寿、当代著名诗人流沙河等一大批能人志士。

由于古镇人文鼎盛以及绣川书院的美名远播，历史上，王勃、李商隐、苏东坡、陆游、杨慎、李调元、于右任、张大千等一大批文人墨客曾慕名来此生活，不仅为古镇增色生辉，而且也为古镇文化注入了源源不断的活力。`
        },
        {
            id: 2,
            title: '武庙',
            image: 'https://p11-doubao-search-sign.byteimg.com/tos-cn-i-qvj2lq49k0/02bdd783ca36459890addf8efe2684b2~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1785769688&x-signature=6d3VmgZv9MrGI03dcOlOdKrpbZA%3D',
            description: `武庙是川西唯一保存完整的县级武庙，供奉关羽，红墙青瓦极具古韵。高度比文庙高近1米，属全国少有。

武庙建筑风格独特，红墙青瓦，雕梁画栋，体现了中国传统建筑的精湛工艺。庙内供奉着三国时期的名将关羽，是当地民众祭祀和参观的重要场所。

武庙的建筑布局严谨，主要建筑沿中轴线排列，包括山门、正殿、后殿等，两侧还有配殿、厢房等辅助建筑。整个建筑群气势恢宏，庄严肃穆，是研究中国古代建筑和宗教文化的重要实物资料。`
        },
        {
            id: 3,
            title: '陈氏宗祠',
            image: 'https://p3-doubao-search-sign.byteimg.com/labis/c9001f3a0b9cccb2973a8f35bc3c56da~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1785769701&x-signature=9aD8l36zuh7yYXTCZRt7uKhRsEA%3D',
            description: `陈氏宗祠是一座有着近300年历史的客家祠堂，见证了湖广移民文化，整体建筑规模宏大、精美豪华。

宗祠建筑风格融合了客家传统建筑特色和川西地方风格，布局严谨，结构精巧，装饰华丽。祠内保存有许多珍贵的历史文物和艺术品，如木雕、砖雕、石雕等，展示了高超的工艺水平。

陈氏宗祠不仅是陈氏家族祭祀祖先、举行宗族活动的场所，也是研究客家文化、移民历史和传统建筑的重要实物资料。每年清明节等重要节日，陈氏后人都会回到宗祠举行隆重的祭祀活动，传承家族文化。`
        },
        {
            id: 4,
            title: '三清观',
            image: 'https://p26-doubao-search-sign.byteimg.com/labis/27fa5d925e445030d0156bb5b685ee7e~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1785769701&x-signature=Y6vjOf1DlyevP6QKeAhEpVFOdQI%3D',
            description: `三清观始建于明代，是青白江区唯一开放的道教场所，与寿佛寺相邻，二者建筑风格独特，体现了道教文化与古建筑的结合。

三清观供奉着道教的三位最高神祗——元始天尊、灵宝天尊和道德天尊（太上老君）。观内建筑布局严谨，主要建筑包括山门、三清殿、玉皇殿等，两侧还有配殿、厢房等辅助建筑。

三清观的建筑风格融合了明清时期的建筑特色，飞檐翘角，雕梁画栋，装饰精美。观内保存有许多珍贵的道教文物和艺术品，如壁画、雕塑、碑刻等，展示了丰富的道教文化内涵。

每年农历正月初九（玉皇大帝诞辰）、二月十五（太上老君诞辰）等重要道教节日，三清观都会举行隆重的法会活动，吸引众多信徒和游客前来参加。`
        },
        {
            id: 5,
            title: '汉代"新都城"遗址公园',
            image: 'https://p3-doubao-search-sign.byteimg.com/tos-cn-i-qvj2lq49k0/fefea139f8624a60b4dfbaeb426bd508~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1785769701&x-signature=kRk9LyKTlMcc%2FVSDoqIqU61GYpE%3D',
            description: `汉代"新都城"遗址公园位于城厢古城西街，距今2000多年的汉代"新都城"西城墙遗址是国内首次完整揭示出汉代城墙、壕沟与包砖"三位一体"结构的城址。

2021年，汉代"新都城"遗址的发现，将城厢古城建城史向前推进700多年，确认了汉代的新都县城就位于现在的城厢古城。该遗址为古今重叠性遗址，是城市考古的又一典型遗存，延续时间久，堆积丰富，为研究汉代城址布局提供了重要资料，再次彰显了成都厚重的历史底蕴。

《华阳国志》记载:"(张)仪与(张)若城成都……与咸阳同制。"也即成都基本仿照咸阳的建制，后世称之为秦城，又作"龟城"。有意思的是，"新都城"遗址所在的青白江城厢古城，至今保留了完整"龟背"城市格局。

成都文物考古研究院院长颜劲松表示，"新都城"遗址以实物证据明确了城厢镇在西汉至三国时期为蜀郡、广汉郡的"新都城"所在地。`
        },
        {
            id: 6,
            title: '城厢古镇全景',
            image: 'https://p3-doubao-search-sign.byteimg.com/labis/6269655afcf226635a374db2e1edfd14~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1785769687&x-signature=feAeE06X7XSPelYjGtTE3IY8sW0%3D',
            description: `城厢古镇布局遵循宋代龟背制格局，保存有1护城河、4条主街、32条巷子以及108座人文院落，是成都平原唯一保留龟背形制的千年古城，被称为老成都的"活沙盘"。

古镇内的建筑多为明清时期的川西民居风格，白墙黑瓦，飞檐翘角，古朴典雅。街道布局严谨，呈棋盘状分布，主要街道有东街、西街、南街、北街四条，与32条巷子相互连通，形成了独特的城市格局。

城厢古镇不仅保存了丰富的历史文化遗产，还有着浓厚的市井文化氛围。古镇内有许多传统的茶馆、小吃店、手工艺品店等，游客可以在这里品尝当地特色美食，购买手工艺品，体验川西传统的市井生活。

近年来，城厢古镇进行了保护性开发，在保留历史风貌的同时，完善了旅游设施，提升了旅游服务质量，成为了成都周边重要的旅游目的地之一。`
        }
    ];
    
    // 打开模态框
    viewDetailsButtons.forEach(button => {
        button.addEventListener('click', function() {
            const attractionId = parseInt(this.getAttribute('data-id'));
            const attraction = attractionsData.find(item => item.id === attractionId);
            
            if (attraction) {
                modalTitle.textContent = attraction.title;
                modalImage.src = attraction.image;
                modalImage.alt = attraction.title;
                modalDescription.textContent = attraction.description;
                
                modal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        });
    });
    
    // 关闭模态框
    function closeModalFunc() {
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
    
    closeModal.addEventListener('click', closeModalFunc);
    modalOverlay.addEventListener('click', closeModalFunc);
    
    // 图片懒加载
    const lazyImages = document.querySelectorAll('img');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const image = entry.target;
                    image.classList.add('loaded');
                    imageObserver.unobserve(image);
                }
            });
        });
        
        lazyImages.forEach(image => {
            imageObserver.observe(image);
        });
    } else {
        // 回退方案
        lazyImages.forEach(image => {
            image.classList.add('loaded');
        });
    }
});